package com.vahana.utils.v1.notifications;

public enum NotificationType {
    NONE,
    RIDE,
}
