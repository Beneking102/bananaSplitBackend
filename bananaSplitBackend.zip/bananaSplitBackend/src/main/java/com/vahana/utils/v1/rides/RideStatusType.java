package com.vahana.utils.v1.rides;

public enum RideStatusType {
    NONE,
    ACTIVE,
    PLANNED,
    CANCELED,
    COMPLETED
}
