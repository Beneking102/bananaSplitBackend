package com.vahana.utils.v1.users;

public enum ActionType {
    NONE,
    CREATE,
    LOGIN,
    LOGOUT,
    DELETE,
    UPDATE
}
