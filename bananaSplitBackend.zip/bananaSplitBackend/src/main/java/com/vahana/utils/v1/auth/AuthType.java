package com.vahana.utils.v1.auth;

public enum AuthType {
    NONE,
    ACCESS,
    REFRESH,
    PASSWORD_RESET,
}
