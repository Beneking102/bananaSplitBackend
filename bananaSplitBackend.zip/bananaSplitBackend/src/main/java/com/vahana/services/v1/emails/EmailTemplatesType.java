package com.vahana.services.v1.emails;

public enum EmailTemplatesType {
    NONE,
    RESET_PASSWORD,
    EMAIL_CHANGED,
}
