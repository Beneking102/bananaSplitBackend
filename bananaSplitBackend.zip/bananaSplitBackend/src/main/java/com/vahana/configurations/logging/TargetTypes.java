package com.vahana.configurations.logging;

public enum TargetTypes {
    SYSTEM,
    AUTH,
    SESSION,
    ENDPOINT
}
