package com.vahana.configurations.logging;

public enum CustomMDCTypes {
    NONE,
    REQUEST_ID,
    TARGET
}
