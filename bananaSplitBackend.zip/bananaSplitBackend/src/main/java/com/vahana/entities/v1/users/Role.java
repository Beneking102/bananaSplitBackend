package com.vahana.entities.v1.users;

public enum Role {
    NONE,
    USER,
    ADMIN
}
